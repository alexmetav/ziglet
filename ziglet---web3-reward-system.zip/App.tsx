
import React, { useState, useEffect, useCallback } from 'react';
import { Task, TaskStatus, UserStats } from './types';
import { FaucetIcon, SocialIcon, MemeIcon, InviteIcon, CheckIcon, CopyIcon } from './components/Icons';

// Sub-components
const Navbar: React.FC<{ connected: boolean; onConnect: () => void }> = ({ connected, onConnect }) => (
  <nav className="sticky top-0 z-50 glass-card px-6 py-4 flex items-center justify-between border-b border-white/5">
    <div className="flex items-center gap-2">
      <div className="w-10 h-10 bg-green-400 rounded-xl flex items-center justify-center shadow-lg neon-glow-green rotate-12">
        <span className="text-zinc-950 font-black text-xl">Z</span>
      </div>
      <span className="text-2xl font-black tracking-tighter neon-text-green">ZIGLET</span>
    </div>
    <div className="hidden md:flex items-center gap-8 text-sm font-medium text-zinc-400">
      <a href="#how-it-works" className="hover:text-green-400 transition-colors">How it Works</a>
      <a href="#faucet" className="hover:text-green-400 transition-colors">Faucet</a>
      <a href="#tasks" className="hover:text-green-400 transition-colors">Tasks</a>
      <a href="#roadmap" className="hover:text-green-400 transition-colors">Roadmap</a>
    </div>
    <button 
      onClick={onConnect}
      className={`px-6 py-2 rounded-full font-bold text-sm transition-all ${
        connected 
        ? 'bg-zinc-800 text-zinc-300 border border-white/10' 
        : 'bg-green-400 text-zinc-950 hover:bg-green-300 neon-glow-green'
      }`}
    >
      {connected ? '0x7...92a1' : 'Connect Wallet'}
    </button>
  </nav>
);

const Hero: React.FC = () => (
  <section className="relative pt-20 pb-32 px-6 overflow-hidden">
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-green-500/10 blur-[120px] rounded-full"></div>
    <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-purple-500/10 blur-[100px] rounded-full"></div>
    <div className="max-w-4xl mx-auto text-center relative z-10">
      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-zinc-900 border border-white/10 mb-8 animate-bounce">
        <span className="flex h-2 w-2 rounded-full bg-green-400"></span>
        <span className="text-xs font-bold text-zinc-300 tracking-wide uppercase">Season 1 is Live</span>
      </div>
      <h1 className="text-5xl md:text-8xl font-black mb-6 tracking-tight leading-tight">
        Get Rewarded for <br />
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-400 via-emerald-400 to-cyan-400">Showing Up.</span>
      </h1>
      <p className="text-lg md:text-xl text-zinc-400 mb-10 max-w-2xl mx-auto leading-relaxed">
        Ziglet turns daily activity, social engagement, and memes into rewards. 
        The more you engage, the more you earn. Simple.
      </p>
      <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
        <button className="w-full sm:w-auto px-8 py-4 bg-green-400 text-zinc-950 rounded-2xl font-bold text-lg hover:scale-105 transition-transform neon-glow-green">
          Start Earning Today
        </button>
        <button className="w-full sm:w-auto px-8 py-4 bg-zinc-900 text-white rounded-2xl font-bold text-lg border border-white/10 hover:bg-zinc-800 transition-colors">
          View How It Works
        </button>
      </div>
    </div>
  </section>
);

const HowItWorks: React.FC = () => {
  const steps = [
    { icon: <FaucetIcon className="w-8 h-8 text-green-400" />, title: 'Claim Faucet', desc: 'Daily point multiplier for consistent users.', reward: '+50 pts' },
    { icon: <SocialIcon className="w-8 h-8 text-cyan-400" />, title: 'Social Boost', desc: 'Like, RT, and engage with the community.', reward: '+100 pts' },
    { icon: <MemeIcon className="w-8 h-8 text-purple-400" />, title: 'Meme Magic', desc: 'Create content using #Ziglet on X.', reward: '+500 pts' },
    { icon: <InviteIcon className="w-8 h-8 text-amber-400" />, title: 'Refer Friends', desc: 'Grow the tribe and earn together.', reward: '10% Bonus' },
  ];

  return (
    <section id="how-it-works" className="py-24 px-6 bg-zinc-950/50">
      <div className="max-w-7xl mx-auto">
        <div className="mb-16">
          <h2 className="text-4xl font-black mb-4">How Ziglet Works</h2>
          <p className="text-zinc-500">Four ways to dominate the leaderboard.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step, idx) => (
            <div key={idx} className="glass-card p-8 rounded-3xl group hover:border-green-400/30 transition-all">
              <div className="mb-6 p-4 rounded-2xl bg-zinc-900 inline-block group-hover:scale-110 transition-transform">{step.icon}</div>
              <h3 className="text-xl font-bold mb-2">{step.title}</h3>
              <p className="text-zinc-500 text-sm mb-6 leading-relaxed">{step.desc}</p>
              <div className="text-green-400 font-bold text-sm tracking-wider uppercase">{step.reward}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const FaucetSection: React.FC<{ onClaim: () => void; claimed: boolean; streak: number }> = ({ onClaim, claimed, streak }) => {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const today = 3; // Mocking as Thursday

  return (
    <section id="faucet" className="py-24 px-6 relative overflow-hidden">
      <div className="max-w-4xl mx-auto">
        <div className="glass-card p-8 md:p-12 rounded-[2.5rem] border-green-500/20 relative">
          <div className="absolute top-0 right-0 p-8">
             <div className="text-center">
                <div className="text-3xl font-black text-green-400 animate-pulse">{streak} 🔥</div>
                <div className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest">Day Streak</div>
             </div>
          </div>
          <h2 className="text-3xl font-black mb-2">Daily Faucet</h2>
          <p className="text-zinc-400 mb-10">New faucet unlocks every day. Don't break your streak.</p>
          
          <div className="grid grid-cols-4 md:grid-cols-7 gap-3 mb-10">
            {days.map((day, i) => (
              <div key={i} className={`flex flex-col items-center gap-3 p-4 rounded-2xl border transition-all ${
                i < today ? 'bg-green-400/10 border-green-400/30' : 
                i === today ? 'bg-zinc-800 border-white/20 scale-105' : 
                'bg-zinc-900 border-white/5 opacity-50'
              }`}>
                <span className="text-[10px] font-bold uppercase text-zinc-500">{day}</span>
                {i < today ? <CheckIcon className="text-green-400 w-5 h-5" /> : <div className="w-5 h-5 rounded-full border-2 border-zinc-700"></div>}
              </div>
            ))}
          </div>

          <button 
            disabled={claimed}
            onClick={onClaim}
            className={`w-full py-5 rounded-2xl font-black text-xl transition-all ${
              claimed 
              ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed' 
              : 'bg-green-400 text-zinc-950 hover:scale-[1.02] neon-glow-green'
            }`}
          >
            {claimed ? 'Already Claimed Today' : 'Claim Daily Reward'}
          </button>
        </div>
      </div>
    </section>
  );
};

const Dashboard: React.FC<{ stats: UserStats }> = ({ stats }) => {
  const tasks: Task[] = [
    { id: '1', title: 'Connect Wallet', reward: 50, icon: <FaucetIcon />, status: TaskStatus.LIVE, isCompleted: true },
    { id: '2', title: 'Follow Ziglet on X', reward: 100, icon: <SocialIcon />, status: TaskStatus.LIVE, isCompleted: false },
    { id: '3', title: 'Join Discord', reward: 100, icon: <SocialIcon />, status: TaskStatus.LIVE, isCompleted: false },
    { id: '4', title: 'Post a Meme with #Ziglet', reward: 500, icon: <MemeIcon />, status: TaskStatus.LIVE, isCompleted: false },
    { id: '5', title: 'Refer 3 Friends', reward: 1000, icon: <InviteIcon />, status: TaskStatus.WIP, isCompleted: false },
  ];

  return (
    <section id="tasks" className="py-24 px-6 bg-zinc-950">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12">
        <div className="lg:col-span-4 space-y-6">
          <div className="glass-card p-8 rounded-3xl border-white/10">
            <h3 className="text-zinc-500 text-sm font-bold uppercase tracking-wider mb-6">Your Profile</h3>
            <div className="space-y-6">
              <div>
                <div className="text-zinc-400 text-xs mb-1">Total Points</div>
                <div className="text-4xl font-black text-white">{stats.points.toLocaleString()} <span className="text-green-400 text-sm">ZIG</span></div>
              </div>
              <div className="h-px bg-white/5"></div>
              <div className="flex justify-between items-center">
                <div className="text-zinc-400 text-xs">Daily Streak</div>
                <div className="font-bold text-orange-400">{stats.streak} Days 🔥</div>
              </div>
              <div className="flex justify-between items-center">
                <div className="text-zinc-400 text-xs">Referrals</div>
                <div className="font-bold text-cyan-400">{stats.referrals}</div>
              </div>
            </div>
          </div>

          <div className="glass-card p-8 rounded-3xl border-purple-500/20 bg-gradient-to-br from-purple-500/5 to-transparent">
             <div className="flex items-center justify-between mb-4">
               <h3 className="font-bold text-lg">Meme Review</h3>
               <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 text-[10px] font-bold">WIP</span>
             </div>
             <p className="text-sm text-zinc-500 mb-6">All meme submissions are manually reviewed by the council within 24 hours.</p>
             <div className="aspect-video bg-zinc-900 rounded-xl border border-white/5 flex items-center justify-center text-zinc-700 italic text-sm">
                Placeholder Meme Card
             </div>
          </div>
        </div>

        <div className="lg:col-span-8">
          <div className="mb-8 flex items-center justify-between">
            <h2 className="text-3xl font-black">Today's Tasks</h2>
            <div className="flex items-center gap-2">
               <span className="text-sm text-zinc-500">Overall Progress</span>
               <div className="w-32 h-2 bg-zinc-900 rounded-full overflow-hidden">
                 <div className="h-full bg-green-400 w-1/4"></div>
               </div>
            </div>
          </div>
          
          <div className="space-y-4">
            {tasks.map((task) => (
              <div key={task.id} className={`glass-card p-6 rounded-2xl flex items-center justify-between group transition-all ${task.status === TaskStatus.WIP ? 'opacity-60 grayscale' : ''}`}>
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${task.isCompleted ? 'bg-green-400/20 text-green-400' : 'bg-zinc-900 text-zinc-400'}`}>
                    {task.isCompleted ? <CheckIcon className="w-6 h-6" /> : task.icon}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold">{task.title}</h4>
                      {task.status === TaskStatus.WIP && (
                        <span className="px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-500 text-[8px] font-black uppercase">WIP</span>
                      )}
                    </div>
                    <div className="text-xs text-zinc-500">Reward: {task.reward} pts</div>
                  </div>
                </div>
                {task.isCompleted ? (
                   <span className="text-green-400 text-xs font-bold uppercase tracking-widest">Completed</span>
                ) : (
                  <button disabled={task.status === TaskStatus.WIP} className={`px-5 py-2 rounded-xl text-xs font-bold transition-all ${
                    task.status === TaskStatus.WIP ? 'bg-zinc-800 text-zinc-600' : 'bg-zinc-800 text-white hover:bg-zinc-700'
                  }`}>
                    {task.status === TaskStatus.WIP ? 'Verification WIP' : 'Go to Task'}
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const ReferralSection: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const refCode = "ZIG-77X-99";

  const handleCopy = () => {
    navigator.clipboard.writeText(`https://ziglet.io/join?ref=${refCode}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section className="py-24 px-6 bg-zinc-950">
      <div className="max-w-4xl mx-auto">
        <div className="glass-card p-10 md:p-16 rounded-[3rem] border-cyan-500/20 text-center relative overflow-hidden">
          <div className="absolute -top-10 -left-10 w-40 h-40 bg-cyan-500/10 blur-[80px] rounded-full"></div>
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-cyan-500/10 blur-[80px] rounded-full"></div>
          
          <h2 className="text-4xl font-black mb-4">Invite Your Tribe</h2>
          <p className="text-zinc-400 mb-10 max-w-md mx-auto">Earn a 10% bonus on all points earned by your referrals. Unlimited invites.</p>
          
          <div className="max-w-md mx-auto bg-zinc-900/50 p-2 rounded-2xl flex items-center border border-white/5 mb-10">
            <div className="flex-1 text-left px-4 font-mono text-cyan-400">ziglet.io/join?ref={refCode}</div>
            <button 
              onClick={handleCopy}
              className="px-6 py-3 rounded-xl bg-cyan-500 text-zinc-950 font-bold hover:bg-cyan-400 transition-colors flex items-center gap-2"
            >
              {copied ? 'Copied!' : <><CopyIcon /> Copy</>}
            </button>
          </div>

          <div className="grid grid-cols-3 gap-4">
             <div className="p-4 rounded-2xl bg-zinc-900 border border-white/5">
                <div className="text-2xl font-black">12</div>
                <div className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest mt-1">Invited</div>
             </div>
             <div className="p-4 rounded-2xl bg-zinc-900 border border-white/5">
                <div className="text-2xl font-black text-green-400">4.2k</div>
                <div className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest mt-1">Earned</div>
             </div>
             <div className="p-4 rounded-2xl bg-zinc-900 border border-white/5">
                <div className="text-2xl font-black text-cyan-400">#42</div>
                <div className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest mt-1">Rank</div>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Roadmap: React.FC = () => {
  const items = [
    { title: 'Public Beta Launch', status: TaskStatus.LIVE, desc: 'Daily Faucet and basic social tasks.' },
    { title: 'Meme Verification Engine', status: TaskStatus.WIP, desc: 'Automated content review using AI.' },
    { title: 'Community Badges', status: TaskStatus.UPCOMING, desc: 'Soulbound tokens for top contributors.' },
    { title: 'TGE & Token Drop', status: TaskStatus.UPCOMING, desc: 'Convert Ziglet points into $ZIG tokens.' },
  ];

  return (
    <section id="roadmap" className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl font-black mb-16 text-center">Transparency & Roadmap</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {items.map((item, i) => (
            <div key={i} className="relative p-8 rounded-3xl bg-zinc-900/50 border border-white/5 group hover:bg-zinc-900 transition-colors">
              <div className="flex items-center justify-between mb-4">
                 <span className={`px-2 py-1 rounded-md text-[10px] font-black uppercase ${
                   item.status === TaskStatus.LIVE ? 'bg-green-400/20 text-green-400' :
                   item.status === TaskStatus.WIP ? 'bg-cyan-400/20 text-cyan-400' :
                   'bg-zinc-800 text-zinc-500'
                 }`}>
                   {item.status}
                 </span>
                 <span className="text-zinc-800 font-black text-4xl">0{i+1}</span>
              </div>
              <h3 className="text-xl font-bold mb-3">{item.title}</h3>
              <p className="text-sm text-zinc-500 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Footer: React.FC = () => (
  <footer className="py-20 px-6 border-t border-white/5 bg-zinc-950">
    <div className="max-w-7xl mx-auto text-center">
      <div className="mb-12">
        <h2 className="text-4xl md:text-6xl font-black mb-6">Start Your Streak Today</h2>
        <button className="px-10 py-5 bg-green-400 text-zinc-950 rounded-2xl font-black text-xl hover:scale-105 transition-transform neon-glow-green">
          Get Started for Free
        </button>
      </div>
      <div className="flex flex-col md:flex-row items-center justify-between gap-8 text-zinc-500 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-zinc-800 rounded-lg flex items-center justify-center font-bold text-white">Z</div>
          <span className="font-bold text-white">ZIGLET</span>
        </div>
        <div className="flex gap-8">
          <a href="#" className="hover:text-white transition-colors">Twitter (X)</a>
          <a href="#" className="hover:text-white transition-colors">Discord</a>
          <a href="#" className="hover:text-white transition-colors">Docs</a>
        </div>
        <div>© 2024 Ziglet Ecosystem. All rights reserved.</div>
      </div>
      <p className="mt-12 text-[10px] text-zinc-600 max-w-3xl mx-auto uppercase tracking-widest leading-loose">
        Disclaimer: Ziglet is currently in early-stage beta. Features and rewards are subject to change as we roll out the full ecosystem. Points do not currently have financial value.
      </p>
    </div>
  </footer>
);

export default function App() {
  const [stats, setStats] = useState<UserStats>({
    points: 1250,
    streak: 3,
    referrals: 12,
    walletConnected: false,
    tasksCompleted: 1
  });
  const [claimed, setClaimed] = useState(false);

  const handleConnect = () => {
    setStats(prev => ({ ...prev, walletConnected: !prev.walletConnected }));
  };

  const handleClaim = () => {
    if (!claimed) {
      setStats(prev => ({
        ...prev,
        points: prev.points + 50,
        streak: prev.streak + 1
      }));
      setClaimed(true);
      // Simulate toast
      alert("Reward Claimed! +50 Points added to your balance.");
    }
  };

  return (
    <div className="min-h-screen">
      <Navbar connected={stats.walletConnected} onConnect={handleConnect} />
      <main>
        <Hero />
        <HowItWorks />
        <FaucetSection onClaim={handleClaim} claimed={claimed} streak={stats.streak} />
        <Dashboard stats={stats} />
        <ReferralSection />
        <Roadmap />
      </main>
      <Footer />
    </div>
  );
}
