import React from 'react';

export enum TaskStatus {
  LIVE = 'live',
  WIP = 'wip',
  UPCOMING = 'upcoming'
}

export interface Task {
  id: string;
  title: string;
  reward: number;
  // Fix: Imported React to ensure the React namespace is available for ReactNode
  icon: React.ReactNode;
  status: TaskStatus;
  isCompleted?: boolean;
}

export interface UserStats {
  points: number;
  streak: number;
  referrals: number;
  walletConnected: boolean;
  tasksCompleted: number;
}